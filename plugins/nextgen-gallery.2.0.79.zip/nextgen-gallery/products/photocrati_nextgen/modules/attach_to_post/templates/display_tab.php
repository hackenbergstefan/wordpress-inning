<div id="errors">
	
</div>
<div class="accordion" id="display_settings_accordion">
<?php foreach($tabs as $tab): ?>
	<?php echo $tab ?>
<?php endforeach ?>
</div>
<p>
	<input type="button" id="save_displayed_gallery" value="<?php _e('Save', 'nggallery'); ?>"/>
</p>